import logo from './logo.svg';
import './App.css';
import CN1 from './Components/CN1';

function App() {
  return (
    <div className="App">
      <CN1/>
    </div>
  );
}

export default App;
